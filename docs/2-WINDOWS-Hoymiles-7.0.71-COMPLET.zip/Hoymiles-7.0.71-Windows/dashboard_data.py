"""Read-only, shared web reports. No device connections and no invented samples."""
import csv
import os
import socket
import subprocess
import sys
import math
import threading
import time
from bisect import bisect_right
from datetime import datetime, timedelta
from pathlib import Path

from battery_monitor import number, household


BATTERY_USABLE_CAPACITY_KWH = 5.76
from autostart import status as autostart_status, set_enabled as set_autostart_enabled


def configured_timestamp(value):
    try:
        return datetime.fromisoformat(str(value)).timestamp()
    except (TypeError, ValueError):
        return None


def icmp_reachable(host):
    """Probe an access point which intentionally exposes no TCP service."""
    if not host:
        return False
    if os.name == "nt":
        command = ["ping", "-n", "1", "-w", "1000", host]
    elif sys.platform == "darwin":
        command = ["ping", "-c", "1", "-W", "1000", host]
    else:
        command = ["ping", "-c", "1", "-W", "1", host]
    try:
        return subprocess.run(
            command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=2, check=False,
        ).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def period_bounds(period, now):
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if period == 'today':
        return midnight, now
    if period == 'yesterday':
        return midnight-timedelta(days=1), midnight
    if period == 'week':
        return midnight-timedelta(days=6), now
    if period == 'month':
        return midnight.replace(day=1), now
    if period == 'year':
        return midnight.replace(month=1, day=1), now
    raise ValueError('Période inconnue')


def read_csv(path):
    if not path.exists():
        return []
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def dated_rows(path):
    result = {}
    for row in read_csv(path):
        try:
            stamp = datetime.fromisoformat(row['date_heure']).timestamp()
            result[stamp] = dict(row, stamp=stamp)
        except (KeyError, TypeError, ValueError):
            continue
    return [result[t] for t in sorted(result)]


def integrate(points, key, start, end):
    energy, seconds = 0.0, 0.0
    for a, b in zip(points, points[1:]):
        left, right = a['stamp'], b['stamp']
        dt = right-left
        pa, pb = number(a.get(key)), number(b.get(key))
        if not 0 < dt <= 180 or pa is None or pb is None:
            continue
        lo, hi = max(start, left), min(end, right)
        if hi <= lo:
            continue
        p0 = pa+(pb-pa)*(lo-left)/dt
        p1 = pa+(pb-pa)*(hi-left)/dt
        energy += (max(0, p0)+max(0, p1))/2*(hi-lo)/3600000
        seconds += hi-lo
    return (energy if seconds else None), seconds


def index_energy(rows, start, end):
    """Only intervals entirely within the requested period. Resets are excluded.

    A long interval between cumulative indexes is valid; it is not an
    interpolation of power. A boundary-straddling interval cannot be assigned
    to the day accurately and is excluded.
    """
    hc = hp = seconds = 0.0
    first = last = None
    for a,b in zip(rows, rows[1:]):
        if not start <= a['stamp'] < b['stamp'] <= end:
            continue
        vals = [number(r.get(k)) for r in (a,b) for k in ('hc_kwh','hp_kwh')]
        if any(v is None for v in vals):
            continue
        dc, dp = vals[2]-vals[0], vals[3]-vals[1]
        if dc < 0 or dp < 0:
            continue
        hc += dc
        hp += dp
        seconds += b['stamp']-a['stamp']
        first = a['stamp'] if first is None else first
        last = b['stamp']
    return dict(hc_kwh=hc if seconds else None, hp_kwh=hp if seconds else None,
                import_kwh=hc+hp if seconds else None, seconds=seconds,
                first=first, last=last, complete=bool(seconds and end-start-seconds <= 180))


def compress_history(points, count=240):
    if len(points) <= count:
        return points
    indexes = {0, len(points)-1}
    step = math.ceil(len(points)/count)
    keys = ('production_w', 'export_w', 'import_w',
            'battery_charge_w', 'battery_discharge_w')
    for left in range(0, len(points), step):
        right = min(left+step, len(points))
        indexes.update((left,right-1))
        for key in keys:
            good = [i for i in range(left,right) if points[i].get(key) is not None]
            if good:
                indexes.add(min(good,key=lambda i:points[i][key]))
                indexes.add(max(good,key=lambda i:points[i][key]))
            missing = next((i for i in range(left,right) if points[i].get(key) is None),None)
            if missing is not None:
                indexes.add(missing)
    return [points[i] for i in sorted(indexes)]


class DashboardData:
    def __init__(self, base, config, battery):
        self.base, self.config, self.battery = Path(base), config, battery
        self.lock = threading.Lock()
        self.cache = {}
        self.esp_lock = threading.Lock()
        self.esp_cache = None
        self.esp_checked = 0

    def report(self, period='today'):
        with self.lock:
            cached = self.cache.get(period)
            if cached and time.monotonic()-cached[0] < 30:
                return cached[1]
            result = self._report(period, datetime.now())
            self.cache[period] = (time.monotonic(), result)
            return result

    def _report(self, period, now):
        start_dt, end_dt = period_bounds(period, now)
        start,end = start_dt.timestamp(),end_dt.timestamp()
        rows = dated_rows(self.base/'hoymiles_log.csv')
        with self.battery.lock:
            battery_rows = list(self.battery.rows)
        stamps = [r['timestamp'] for r in battery_rows]
        def battery_at(stamp):
            i = bisect_right(stamps,stamp)-1
            return battery_rows[i] if i>=0 and stamp-stamps[i]<=45 else {}
        cfg = self.config
        enabled = lambda k: bool(cfg.get(k,{}).get('enabled'))
        complete = bool(cfg.get('production_complete'))
        extended = enabled('battery') or enabled('shelly2')
        points = []
        for r in rows:
            if not start-180 <= r['stamp'] <= end+180:
                continue
            b = battery_at(r['stamp'])
            dtu_pv = number(r.get('production_ac_w'))
            shelly_pv = number(r.get('shelly_a_w')) if enabled('shelly') else None
            grid = number(r.get('shelly_b_w')) if enabled('shelly') else None
            if grid is not None and cfg.get('shelly',{}).get('grid_export_positive'):
                grid = -grid
            if extended:
                pv1 = shelly_pv
                pv2 = number(b.get('pv2_w')) if enabled('shelly2') else (0.0 if complete else None)
                # Une seconde installation non mesurée rend le total incomplet,
                # mais ne doit pas masquer l'énergie réellement vue par Shelly 1.
                pv = (pv1+pv2 if pv1 is not None and pv2 is not None else
                      pv1 if pv1 is not None else pv2)
                bflow = b if b.get('ac_charge_w') is not None and b.get('ac_discharge_w') is not None else None
                if not enabled('battery'):
                    bflow = dict(ac_charge_w=0,ac_discharge_w=0)
                consumption = household(pv1,pv2,grid,bflow,complete)
            else:
                pv1, pv2 = shelly_pv, None
                pv = dtu_pv if dtu_pv is not None else shelly_pv
                consumption = None if shelly_pv is None or grid is None else max(0.0, shelly_pv+grid)
            points.append(dict(stamp=r['stamp'], timestamp=datetime.fromtimestamp(r['stamp']).isoformat(),
                               production_w=pv, pv1_w=pv1, pv2_w=pv2,
                               consumption_w=consumption,
                               import_w=None if grid is None else max(0,grid),
                               export_w=None if grid is None else max(0,-grid),
                               battery_charge_w=number(b.get('charge_w')),
                               battery_discharge_w=number(b.get('discharge_w'))))
        production, pv_seconds = integrate(points,'production_w',start,end)
        consumption, consumption_seconds = integrate(points, 'consumption_w', start, end)
        exported, grid_seconds = integrate(points,'export_w',start,end)
        billing = index_energy(dated_rows(self.base/'linky_index_log.csv'),start,end) if enabled('linky') else index_energy([],start,end)
        tariffs = cfg.get('tarifs_edf',{})
        annual_readings = cfg.get('annual_real_readings', {})
        if not isinstance(annual_readings, dict):
            annual_readings = {}
        annual_reference = annual_readings.get('reference_2025', {})
        if not isinstance(annual_reference, dict):
            annual_reference = {}
        # A manually entered annual total is the reference history.  Once an
        # automatic baseline is set, only measurements after that precise
        # moment are appended.  This makes the annual page progress every day
        # without ever counting the old history twice.
        annual_display = dict(annual_readings)
        automatic_baseline = annual_readings.get('automatic_baseline', {})
        if not isinstance(automatic_baseline, dict):
            automatic_baseline = {}
        source_baselines = automatic_baseline.get('sources', {})
        if not isinstance(source_baselines, dict):
            source_baselines = {}
        def annual_source(name):
            source = source_baselines.get(name)
            if isinstance(source, dict):
                return number(source.get('value')), configured_timestamp(source.get('at')), source.get('at')
            return number(automatic_baseline.get(name)), configured_timestamp(automatic_baseline.get('at')), automatic_baseline.get('at')
        source_dates = [annual_source(name)[1] for name in ('hp_kwh', 'hc_kwh', 'production_kwh', 'export_kwh', 'battery_charge_kwh', 'battery_discharge_kwh')]
        source_dates = [stamp for stamp in source_dates if stamp is not None]
        automatic_from = min(source_dates) if source_dates else None
        if period == 'year' and automatic_from is not None and start <= automatic_from <= end:
            def annual_plus(name, key=None, battery_key=None):
                base, source_at, _ = annual_source(name)
                if base is None or source_at is None:
                    return None
                if key:
                    added, _ = integrate(points, key, source_at, end)
                elif battery_key:
                    added = self.battery.totals(source_at, end)[battery_key]
                else:
                    added = None
                return base + (added or 0.0)
            def annual_index(name, index_key):
                base, source_at, _ = annual_source(name)
                if base is None or source_at is None:
                    return None
                added = index_energy(dated_rows(self.base/'linky_index_log.csv'), source_at, end)[index_key] if enabled('linky') else None
                return base + (added or 0.0)
            automatic_label = min((annual_source(name)[2] for name in ('hp_kwh', 'hc_kwh', 'production_kwh', 'export_kwh', 'battery_charge_kwh', 'battery_discharge_kwh') if annual_source(name)[2]), default=None)
            annual_display.update(
                as_of=now.date().isoformat(),
                hp_kwh=annual_index('hp_kwh', 'hp_kwh'),
                hc_kwh=annual_index('hc_kwh', 'hc_kwh'),
                production_kwh=annual_plus('production_kwh', key='production_w'),
                export_kwh=annual_plus('export_kwh', key='export_w'),
                battery_charge_kwh=annual_plus('battery_charge_kwh', battery_key='ac_charge_kwh'),
                battery_discharge_kwh=annual_plus('battery_discharge_kwh', battery_key='ac_discharge_kwh'),
                automatic_from=automatic_label,
            )
        hp_rate, hc_rate = number(tariffs.get('hp_eur_kwh')),number(tariffs.get('hc_eur_kwh'))
        energy_cost = None
        if billing['import_kwh'] is not None and hp_rate is not None and hc_rate is not None and hp_rate>0 and hc_rate>0:
            energy_cost = billing['hp_kwh']*hp_rate+billing['hc_kwh']*hc_rate
        solar_after_export = None
        if production is not None and exported is not None:
            solar_after_export = max(0.0, production-exported)
        totals = self.battery.totals(start,end)
        # Use the AC flows for the financial balance.  The pack-side values
        # are useful to monitor the battery itself, but do not describe the
        # energy available to the house after conversion losses.
        battery_charge = totals['ac_charge_kwh'] if totals['battery_seconds'] else None
        battery_discharge = totals['ac_discharge_kwh'] if totals['battery_seconds'] else None
        # The state of charge is the only trustworthy way to say what is
        # available in the battery now.  Do not mistake an accumulated flow
        # for stored energy.
        start_soc_row = next((r for r in battery_rows
                              if start <= r.get('timestamp', 0) <= start + 6 * 3600
                              and number(r.get('soc_pct')) is not None), None)
        end_soc_row = next((r for r in reversed(battery_rows)
                            if end - 300 <= r.get('timestamp', 0) <= end
                            and number(r.get('soc_pct')) is not None), None)
        start_soc = number(start_soc_row.get('soc_pct')) if start_soc_row else None
        end_soc = number(end_soc_row.get('soc_pct')) if end_soc_row else None
        battery_available = None if end_soc is None else BATTERY_USABLE_CAPACITY_KWH * end_soc / 100
        battery_storage_change = None
        battery_loss = None
        if start_soc is not None and end_soc is not None:
            battery_storage_change = BATTERY_USABLE_CAPACITY_KWH * (end_soc-start_soc) / 100
            if battery_charge is not None and battery_discharge is not None:
                # AC energy that neither came back to the house nor remains
                # stored.  It is an estimate: conversion losses and any short
                # missing measurement intervals are grouped transparently.
                battery_loss = max(0.0, battery_charge-battery_discharge-battery_storage_change)
        # A DTU interruption must not turn solar energy into an artificial
        # loss.  The grid meter remains the reference for export; the solar
        # energy retained locally is then split between the house and the
        # battery.  What remains in the battery (and conversion losses) is
        # deliberately excluded from the avoided-cost calculation.
        local_energy = None
        battery_retained_or_loss = None
        avoided_cost = None
        if solar_after_export is not None and battery_charge is not None and battery_discharge is not None:
            battery_retained_or_loss = battery_charge-battery_discharge
            # A negative balance means that the house also used energy stored
            # before the start of the selected period.
            local_energy = max(0.0, solar_after_export-battery_retained_or_loss)
            if energy_cost is not None and billing['import_kwh'] > 0:
                avoided_cost = local_energy*energy_cost/billing['import_kwh']
        # Calendar days, not DST-dependent 24-hour intervals.
        days = (end_dt.date()-start_dt.date()).days + (0 if end_dt.time()==datetime.min.time() else 1)
        daily_fee = number(tariffs.get('abonnement_journalier_eur'))
        subscription = None if daily_fee is None else max(0,days)*daily_fee
        return dict(period=period, from_time=start_dt.isoformat(), to_time=end_dt.isoformat(),
                    updated_at=now.isoformat(timespec='seconds'), production_kwh=production,
                    production_complete=complete, export_kwh=exported, pv_seconds=pv_seconds,
                    grid_seconds=grid_seconds, billing=billing, energy_cost=energy_cost,
                    subscription=subscription, total_cost=None if energy_cost is None or subscription is None else energy_cost+subscription,
                    consumption_kwh=consumption, consumption_seconds=consumption_seconds,
                    local_energy_kwh=local_energy, avoided_cost_eur=avoided_cost,
                    solar_after_export_kwh=solar_after_export,
                    battery_retained_or_loss_kwh=battery_retained_or_loss,
                    battery_soc_pct=end_soc,
                    battery_available_kwh=battery_available,
                    battery_storage_change_kwh=battery_storage_change,
                    battery_loss_kwh=battery_loss,
                    tariffs=dict(hp_eur_kwh=hp_rate, hc_eur_kwh=hc_rate,
                                 abonnement_journalier_eur=daily_fee,
                                 abonnement_mensuel_eur=number(tariffs.get('abonnement_mensuel_eur'))),
                    # Optional manual readings are intentionally configuration data:
                    # they are site-specific and must never be inferred from a
                    # partial history or published with the software.
                    annual_real_readings=dict(
                        start=annual_display.get('start'),
                        as_of=annual_display.get('as_of'),
                        automatic_from=annual_display.get('automatic_from'),
                        hp_kwh=number(annual_display.get('hp_kwh')),
                        hc_kwh=number(annual_display.get('hc_kwh')),
                        production_kwh=number(annual_display.get('production_kwh')),
                        export_kwh=number(annual_display.get('export_kwh')),
                        battery_charge_kwh=number(annual_display.get('battery_charge_kwh')),
                        battery_discharge_kwh=number(annual_display.get('battery_discharge_kwh')),
                        battery_start=annual_display.get('battery_start'),
                        battery_end=annual_display.get('battery_end'),
                        savings_eur=number(annual_display.get('savings_eur')),
                        reference_2025=dict(
                            consumption_start=annual_reference.get('consumption_start'),
                            end=annual_reference.get('end'),
                            subscription_start=annual_reference.get('subscription_start'),
                            hp_kwh=number(annual_reference.get('hp_kwh')),
                            hc_kwh=number(annual_reference.get('hc_kwh')),
                            hp_eur_kwh=number(annual_reference.get('hp_eur_kwh')),
                            hc_eur_kwh=number(annual_reference.get('hc_eur_kwh')),
                            subscription_monthly_eur=number(annual_reference.get('subscription_monthly_eur')),
                        ),
                    ),
                    battery_charge_kwh=battery_charge,
                    battery_discharge_kwh=battery_discharge,
                    history=compress_history([p for p in points if start<=p['stamp']<=end]),
                    source='Index Linky enregistrés ; intervalles à cheval sur la période exclus. Les relevés EDF manuels restent accessibles dans les outils classiques.')

    def esp_devices(self):
        with self.esp_lock:
            if self.esp_cache is not None and time.monotonic()-self.esp_checked < 15:
                return self.esp_cache
            proxy = self.config.get('hoymiles_proxy', {})
            router = self.config.get('esp_router', {})
            tp_link = self.config.get('tp_link', {})
            devices = [dict(id='proxy', name='ESP32 — proxy Bluetooth cabanon',
                            hosts=[str(proxy.get('host') or '')], port=int(proxy.get('port',6053)),
                            role='Près des panneaux cabanon · liaison Bluetooth', enabled=bool(proxy.get('enabled', False))),
                       dict(id='router', name='ESP32 — routeur Wi-Fi Solaire cabanon',
                            hosts=[str(router.get('ap_host') or ''), str(router.get('host') or '')], port=80,
                            role='Point d’accès Wi-Fi local', enabled=bool(router.get('enabled', False)),
                            probe='icmp')]
            for device in devices:
                reachable = []
                for host in device['hosts'] if device['enabled'] else []:
                    if device.get('probe') == 'icmp':
                        if icmp_reachable(host):
                            reachable.append(host)
                    else:
                        try:
                            with socket.create_connection((host, device['port']), timeout=1):
                                reachable.append(host)
                        except OSError:
                            pass
                device.update(reachable_hosts=reachable, connected=bool(reachable), checked_at=time.time())
            self.esp_cache, self.esp_checked = devices, time.monotonic()
            return devices

    @staticmethod
    def wireless_interfaces():
        """Return the two USB Wi-Fi links and their useful network references.

        An Alfa USB adapter is an interface of the Raspberry Pi, not a device
        with its own Livebox lease.  Showing that explicitly avoids sending
        the user looking for a non-existent Alfa IP in the Livebox.
        """
        states = {}
        try:
            completed = subprocess.run(
                ['nmcli', '-t', '-f', 'DEVICE,STATE', 'device', 'status'],
                capture_output=True, text=True, timeout=2, check=False,
                env={**os.environ, 'LC_ALL': 'C'},
            )
            if completed.returncode == 0:
                for line in (completed.stdout or '').splitlines():
                    interface, separator, state = line.partition(':')
                    if separator:
                        # NetworkManager may preserve the interface spelling
                        # supplied by a USB driver (for example ``WLAN2``).
                        # Linux interface matching is otherwise
                        # case-sensitive, while our two expected links are
                        # deliberately named in lower case below.
                        states[interface.lower()] = state
        except (OSError, subprocess.SubprocessError):
            pass

        links = (
            ('wlan1', 'Alfa AWUS036NHA — Wi-Fi direct DTU',
             'Liaison Wi-Fi directe vers le DTU',
             ('TP-Link / réseau local', 'DTU local')),
            ('wlan2', 'Alfa · antenne Wi-Fi solaire cabanon',
             'USB 3.0 obligatoire · liaison Wi-Fi vers le cabanon',
             ('Clé USB : aucune adresse Livebox propre',
              'Routeur ESP', 'Proxy Hoymiles')),
        )
        result = []
        for interface, name, role, references in links:
            connected = states.get(interface) == 'connected'
            if interface not in states:
                try:
                    connected = Path('/sys/class/net', interface, 'operstate').read_text().strip() == 'up'
                except OSError:
                    connected = False
            result.append(dict(interface=interface, name=name, role=role,
                               references=list(references), connected=connected))
        return result

    def settings(self):
        result = {'dtu_host':str(self.config.get('dtu_host','')),
                  'settings_password_enabled':bool(isinstance(self.config.get('settings_password'),dict) and self.config.get('settings_password',{}).get('salt') and self.config.get('settings_password',{}).get('digest')),
                  'production_complete':bool(self.config.get('production_complete')),
                  'tarifs_edf':{k:self.config.get('tarifs_edf',{}).get(k) for k in
                                ('hp_eur_kwh','hc_eur_kwh','abonnement_journalier_eur','plages_hc')}}
        for name in ('linky','shelly','battery','shelly2','tp_link','tongou_relay','hoymiles_proxy','esp_router'):
            item=self.config.get(name,{})
            result[name]={k:item.get(k) for k in ('enabled','host','reverse')}
        result['esp_devices'] = self.esp_devices()
        result['wireless_interfaces'] = self.wireless_interfaces()
        result['raspberry_service_enabled'] = None
        try:
            if 'Raspberry Pi' in Path('/proc/device-tree/model').read_text(errors='ignore'):
                check = subprocess.run(['/usr/bin/systemctl', 'is-enabled', 'boite-noire-hoymiles.service'], capture_output=True, text=True, timeout=3, check=False)
                state = check.stdout.strip()
                if state in ('enabled', 'enabled-runtime'):
                    result['raspberry_service_enabled'] = state == 'enabled'
                elif state in ('disabled', 'masked'):
                    result['raspberry_service_enabled'] = False
        except (OSError, subprocess.SubprocessError):
            pass
        try:
            result['autostart'] = autostart_status(self.base)
        except OSError:
            # systemd owns automatic startup on Raspberry Pi / Linux.  The
            # web dashboard must stay usable even though the desktop helper
            # only exists on Windows and macOS.
            result['autostart'] = {'enabled': False, 'computer': 'Raspberry Pi'}
        return result

    def set_autostart(self, enabled):
        if not isinstance(enabled, bool):
            raise ValueError('Le choix Oui ou Non est nécessaire.')
        return set_autostart_enabled(enabled, self.base)
