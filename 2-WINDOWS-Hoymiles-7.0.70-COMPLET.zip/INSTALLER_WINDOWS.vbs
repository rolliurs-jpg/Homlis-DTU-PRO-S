Option Explicit

Dim shell, fso, folder, appData, backup, configFile, choice
Dim dtuHost, dinkyHost, shellyHost, shellyChoice, shellyJson, shelly2Host, shelly2Choice, shelly2Json, json, outputFile, inputFile, shortcut, desktop, result, q, modeFile, dtuMode, chooser, re, existingConfig

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
q = Chr(34)
folder = fso.GetParentFolderName(WScript.ScriptFullName)
appData = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\BoiteNoireHoymiles"
backup = appData & "\sauvegarde_avant_mise_a_jour"
configFile = appData & "\config_v5.json"

If Not fso.FileExists(folder & "\requirements.txt") Then
    MsgBox "L'installateur est lance directement depuis le fichier ZIP." & vbCrLf & vbCrLf & _
           "Cliquez d'abord sur Extraire tout, ouvrez le dossier extrait, puis relancez INSTALLER_WINDOWS.vbs.", _
           vbExclamation, "Boite noire Hoymiles - extraction necessaire"
    WScript.Quit 1
End If

choice = MsgBox("Installer ou mettre a jour Boite noire Hoymiles 7.0.69 ?" & vbCrLf & vbCrLf & "Les historiques et les reglages deja presents seront conserves.", vbOKCancel + vbQuestion, "Confirmer l'installation")
If choice <> vbOK Then WScript.Quit 0

' Installation des dependances sans fenetre de terminal.
result = shell.Run("py.exe -3 -m pip install -r " & Chr(34) & folder & "\requirements.txt" & Chr(34), 0, True)
If result <> 0 Then
    MsgBox "Python ou les dependances sont introuvables." & vbCrLf & "Installez Python 3.10 ou plus depuis python.org, puis relancez cet installateur.", vbExclamation, "Boite noire Hoymiles"
    WScript.Quit 1
End If

If Not fso.FolderExists(appData) Then fso.CreateFolder(appData)
If Not fso.FolderExists(backup) Then fso.CreateFolder(backup)
If fso.FileExists(configFile) Then fso.CopyFile configFile, backup & "\config_v5.json", True
If fso.FileExists(appData & "\hoymiles_log.csv") Then fso.CopyFile appData & "\hoymiles_log.csv", backup & "\hoymiles_log.csv", True
If fso.FileExists(appData & "\linky_index_log.csv") Then fso.CopyFile appData & "\linky_index_log.csv", backup & "\linky_index_log.csv", True

existingConfig = fso.FileExists(configFile)
choice = vbNo
If existingConfig Then
    choice = MsgBox("Les reglages existants sont conserves." & vbCrLf & vbCrLf & "Voulez-vous modifier la connexion du DTU ?", vbYesNoCancel + vbQuestion, "Boite noire Hoymiles - connexion DTU")
    If choice = vbCancel Then WScript.Quit 0
End If

If (Not existingConfig) Or choice = vbYes Then
    chooser = folder & "\CHOISIR_RESEAU.ps1"
    modeFile = shell.ExpandEnvironmentStrings("%TEMP%") & "\BoiteNoireHoymiles_mode_reseau.txt"
    If fso.FileExists(modeFile) Then fso.DeleteFile modeFile, True
    result = shell.Run("powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & q & chooser & q & " -ResultPath " & q & modeFile & q, 0, True)
    If Not fso.FileExists(modeFile) Then WScript.Quit 0

    Set outputFile = fso.OpenTextFile(modeFile, 1, False)
    dtuMode = UCase(Trim(outputFile.ReadAll))
    outputFile.Close
    fso.DeleteFile modeFile, True

    If dtuMode = "WIFI" Then
        dtuHost = "10.10.100.254"
    ElseIf dtuMode = "LAN" Then
        dtuHost = Trim(InputBox("Adresse IP du DTU attribuee par la box :", "Reseau unique - DTU sur nano-routeur/LAN"))
        If dtuHost = "" Then
            MsgBox "Installation annulee : l'adresse IP du DTU est necessaire.", vbExclamation, "Boite noire Hoymiles"
            WScript.Quit 1
        End If
    Else
        WScript.Quit 0
    End If
    If existingConfig Then
        Set inputFile = fso.OpenTextFile(configFile, 1, False)
        json = inputFile.ReadAll
        inputFile.Close
        Set re = New RegExp
        re.Global = False
        re.Pattern = q & "dtu_host" & q & ":" & q & "[^" & q & "]*" & q
        json = re.Replace(json, q & "dtu_host" & q & ":" & q & dtuHost & q)
        If dtuMode = "LAN" Then
            re.Pattern = q & "dtu_wifi_recovery" & q & "\s*:\s*\{[^}]*\}"
            If re.Test(json) Then
                json = re.Replace(json, q & "dtu_wifi_recovery" & q & ":{" & q & "enabled" & q & ":false," & q & "interface" & q & ":" & q & q & "," & q & "profile" & q & ":" & q & q & "," & q & "after_minutes" & q & ":30}")
            End If
        End If
    Else
        dinkyHost = Trim(InputBox("Adresse IP du Dinky (laisser vide si absent) :", "Dinky sur Livebox"))
        dinkyEnabled = "false"
        If dinkyHost <> "" Then dinkyEnabled = "true"
        json = "{" & q & "dtu_host" & q & ":" & q & dtuHost & q & "," & _
               q & "linky" & q & ":{" & q & "enabled" & q & ":" & dinkyEnabled & "," & _
               q & "mode" & q & ":" & q & "dinky_http" & q & "," & _
               q & "host" & q & ":" & q & dinkyHost & q & "," & _
               q & "port" & q & ":80," & q & "timeout_s" & q & ":2," & _
               q & "path" & q & ":" & q & "Status 8" & q & "}," & _
               q & "tarifs_edf" & q & ":{" & q & "hp_eur_kwh" & q & ":0.0," & _
               q & "hc_eur_kwh" & q & ":0.0," & q & "abonnement_mensuel_eur" & q & ":0.0," & _
               q & "abonnement_journalier_eur" & q & ":0.63," & q & "plages_hc" & q & ":" & q & q & "," & _
               q & "ddsu_import_positif" & q & ":true}," & _
               q & "dtu_wifi_recovery" & q & ":{" & q & "enabled" & q & ":false," & _
               q & "interface" & q & ":" & q & q & "," & q & "profile" & q & ":" & q & q & "," & _
               q & "after_minutes" & q & ":30}," & q & "releves_edf" & q & ":{}}"
    End If
    Set outputFile = fso.CreateTextFile(configFile, True, False)
    outputFile.Write json
    outputFile.Close
End If

' Le Shelly Pro EM est facultatif et reste exclusivement en lecture seule.
shellyChoice = MsgBox("Souhaitez-vous configurer ou modifier le Shelly Pro EM ?" & vbCrLf & vbCrLf & _
                      "Oui : saisir ou modifier son adresse IP." & vbCrLf & _
                      "Non : conserver la configuration Shelly actuelle sans aucun changement." & vbCrLf & vbCrLf & _
                      "Le logiciel lit uniquement les deux pinces et ne commande jamais le relais.", _
                      vbYesNo + vbQuestion, "Shelly Pro EM")
If shellyChoice = vbYes Then
    shellyHost = Trim(InputBox("Adresse IP du Shelly Pro EM :", "Shelly Pro EM sur la box"))
    If shellyHost <> "" Then
        If json = "" And fso.FileExists(configFile) Then
            Set inputFile = fso.OpenTextFile(configFile, 1, False)
            json = inputFile.ReadAll
            inputFile.Close
        End If
        shellyJson = q & "shelly" & q & ":{" & q & "enabled" & q & ":true," & _
                     q & "host" & q & ":" & q & shellyHost & q & "," & _
                     q & "port" & q & ":80," & q & "timeout_s" & q & ":2," & _
                     q & "channel_a_label" & q & ":" & q & "Production panneaux Shelly" & q & "," & _
                     q & "channel_b_label" & q & ":" & q & "Reseau EDF - mesure Shelly" & q & "," & _
                     q & "grid_export_positive" & q & ":false}"
        Set re = New RegExp
        re.Global = False
        re.Pattern = q & "shelly" & q & "\s*:\s*\{[^}]*\}"
        If re.Test(json) Then
            json = re.Replace(json, shellyJson)
        Else
            json = Left(Trim(json), Len(Trim(json)) - 1) & "," & shellyJson & "}"
        End If
        Set outputFile = fso.CreateTextFile(configFile, True, False)
        outputFile.Write json
        outputFile.Close
    End If
End If

' Le second Shelly mesure exclusivement les nouveaux panneaux sur le canal A.
shelly2Choice = MsgBox("Souhaitez-vous configurer ou modifier le Shelly EM Gen3 des nouveaux panneaux ?" & vbCrLf & vbCrLf & _
                       "Oui : saisir son adresse IP et activer la production 2." & vbCrLf & _
                       "Non : conserver le reglage actuel sans changement.", _
                       vbYesNo + vbQuestion, "Shelly EM Gen3 - production 2")
If shelly2Choice = vbYes Then
    shelly2Host = Trim(InputBox("Adresse IP du Shelly EM Gen3 :", "Nouveaux panneaux - production 2"))
    If shelly2Host <> "" Then
        If json = "" And fso.FileExists(configFile) Then
            Set inputFile = fso.OpenTextFile(configFile, 1, False)
            json = inputFile.ReadAll
            inputFile.Close
        End If
        shelly2Json = q & "shelly2" & q & ":{" & q & "enabled" & q & ":true," & _
                      q & "host" & q & ":" & q & shelly2Host & q & "," & _
                      q & "port" & q & ":80," & q & "timeout_s" & q & ":2," & _
                      q & "channel" & q & ":0," & q & "reverse" & q & ":false}"
        Set re = New RegExp
        re.Global = False
        re.Pattern = q & "shelly2" & q & "\s*:\s*\{[^}]*\}"
        If re.Test(json) Then
            json = re.Replace(json, shelly2Json)
        Else
            json = Left(Trim(json), Len(Trim(json)) - 1) & "," & shelly2Json & "}"
        End If
        re.Pattern = q & "production_complete" & q & "\s*:\s*(true|false)"
        If re.Test(json) Then
            json = re.Replace(json, q & "production_complete" & q & ":true")
        Else
            json = Left(Trim(json), Len(Trim(json)) - 1) & "," & q & "production_complete" & q & ":true}"
        End If
        Set outputFile = fso.CreateTextFile(configFile, True, False)
        outputFile.Write json
        outputFile.Close
    End If
End If

fso.CopyFile folder & "\boite_noire_hoymiles.py", appData & "\boite_noire_hoymiles.py", True
fso.CopyFile folder & "\mobile_dashboard.py", appData & "\mobile_dashboard.py", True
fso.CopyFile folder & "\dashboard_data.py", appData & "\dashboard_data.py", True
fso.CopyFile folder & "\dashboard_ui.html", appData & "\dashboard_ui.html", True
fso.CopyFile folder & "\autostart.py", appData & "\autostart.py", True
fso.CopyFile folder & "\monitoring.py", appData & "\monitoring.py", True
fso.CopyFile folder & "\energy_analysis.py", appData & "\energy_analysis.py", True
fso.CopyFile folder & "\surplus_simulation.py", appData & "\surplus_simulation.py", True
fso.CopyFile folder & "\surplus_controller.py", appData & "\surplus_controller.py", True
fso.CopyFile folder & "\dtu_control.py", appData & "\dtu_control.py", True
fso.CopyFile folder & "\PAIRER_HOYMILES.py", appData & "\PAIRER_HOYMILES.py", True
fso.CopyFile folder & "\hoymiles_proxy.py", appData & "\hoymiles_proxy.py", True
fso.CopyFile folder & "\HOYMILES_BLE_LICENSE.txt", appData & "\HOYMILES_BLE_LICENSE.txt", True
fso.CopyFile folder & "\battery_monitor.py", appData & "\battery_monitor.py", True
fso.CopyFile folder & "\fond_solaire.png", appData & "\fond_solaire.png", True
fso.CopyFile folder & "\icone_panneau_solaire.ico", appData & "\icone_panneau_solaire.ico", True
fso.CopyFile folder & "\LANCER.vbs", appData & "\LANCER.vbs", True
fso.CopyFile folder & "\LANCER_INTERFACE_WEB.vbs", appData & "\LANCER_INTERFACE_WEB.vbs", True
fso.CopyFile folder & "\CHOISIR_INTERFACE.vbs", appData & "\CHOISIR_INTERFACE.vbs", True

desktop = shell.SpecialFolders("Desktop")
Set shortcut = shell.CreateShortcut(desktop & "\Boite noire Hoymiles.lnk")
shortcut.TargetPath = shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\wscript.exe"
shortcut.Arguments = Chr(34) & appData & "\CHOISIR_INTERFACE.vbs" & Chr(34)
shortcut.WorkingDirectory = appData
shortcut.IconLocation = appData & "\icone_panneau_solaire.ico,0"
shortcut.Save
MsgBox "Installation terminee." & vbCrLf & "Le raccourci du Bureau permet maintenant de choisir entre la nouvelle interface web et l'ancien logiciel." & vbCrLf & vbCrLf & "Les historiques et reglages existants sont conserves.", vbInformation, "Boite noire Hoymiles"
