#!/usr/bin/env bash
# Installe ou met à jour le collecteur sur Raspberry Pi OS.
# Les réglages et historiques restent dans le dossier personnel de l'utilisateur.
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALL_DIR="${1:-$HOME/solaire}"
SERVICE_NAME="boite-noire-hoymiles.service"
RECOVERY_SERVICE="solaire-network-recovery.service"
RECOVERY_TIMER="solaire-network-recovery.timer"
USER_NAME="$(id -un)"
NETWORK_ENV="/etc/solaire-network.env"
ALFA_PROFILE="solaire-cabanon-alfa"
ALFA_SSID="Cabanon Solaire"
ALFA_BSSID="70:4B:CA:16:BC:C9"
DTU_PROFILE="${DTU_WIFI_PROFILE:-dtu-direct-4p}"
PRIMARY_WIFI_PROFILE="${PRIMARY_WIFI_PROFILE:-netplan-wlan0-livebox-B560}"

if [ "$(id -u)" -eq 0 ]; then
  echo "Lancez cet installateur depuis votre compte Raspberry habituel, sans sudo."
  exit 1
fi

echo "Installation de Boîte noire Hoymiles dans : $INSTALL_DIR"
sudo apt update
sudo apt install -y python3-venv

mkdir -p "$INSTALL_DIR/raspberry-pi"
FILES=(
  boite_noire_hoymiles.py mobile_dashboard.py dashboard_data.py dashboard_ui.html
  autostart.py monitoring.py energy_analysis.py battery_monitor.py
  surplus_simulation.py surplus_controller.py dtu_control.py PAIRER_HOYMILES.py
  hoymiles_proxy.py local_dtu_probe.py HOYMILES_BLE_LICENSE.txt requirements.txt fond_solaire.png
  icone_panneau_solaire.ico config.example.json README.md
)
for file in "${FILES[@]}"; do
  install -m 0644 "$SOURCE_DIR/$file" "$INSTALL_DIR/$file"
done
install -m 0644 "$SOURCE_DIR/raspberry-pi/README.md" "$INSTALL_DIR/raspberry-pi/README.md"
install -m 0644 "$SOURCE_DIR/raspberry-pi/boite-noire-hoymiles.service.example" "$INSTALL_DIR/raspberry-pi/boite-noire-hoymiles.service.example"
install -m 0755 "$SOURCE_DIR/raspberry-pi/solaire-network-recovery.sh" "$INSTALL_DIR/raspberry-pi/solaire-network-recovery.sh"
install -m 0644 "$SOURCE_DIR/raspberry-pi/solaire-network-recovery.service.example" "$INSTALL_DIR/raspberry-pi/solaire-network-recovery.service.example"
install -m 0644 "$SOURCE_DIR/raspberry-pi/solaire-network-recovery.timer.example" "$INSTALL_DIR/raspberry-pi/solaire-network-recovery.timer.example"

if [ ! -f "$HOME/AppData/Local/BoiteNoireHoymiles/config_v5.json" ]; then
  mkdir -p "$HOME/AppData/Local/BoiteNoireHoymiles"
  install -m 0600 "$SOURCE_DIR/config.example.json" "$HOME/AppData/Local/BoiteNoireHoymiles/config_v5.json"
  echo "Configuration vierge créée dans $HOME/AppData/Local/BoiteNoireHoymiles/config_v5.json"
  echo "Renseignez vos propres équipements depuis le tableau web, puis relancez le service."
fi

python3 -m venv "$INSTALL_DIR/.venv"
"$INSTALL_DIR/.venv/bin/python" -m pip install --upgrade pip
"$INSTALL_DIR/.venv/bin/python" -m pip install -r "$INSTALL_DIR/requirements.txt"

sed \
  -e "s|/home/YOUR_LINUX_USER/solaire|$INSTALL_DIR|g" \
  -e "s|YOUR_LINUX_USER|$USER_NAME|g" \
  "$INSTALL_DIR/raspberry-pi/boite-noire-hoymiles.service.example" \
  | sudo tee "/etc/systemd/system/$SERVICE_NAME" >/dev/null
sed \
  -e "s|/home/YOUR_LINUX_USER/solaire|$INSTALL_DIR|g" \
  "$INSTALL_DIR/raspberry-pi/solaire-network-recovery.service.example" \
  | sudo tee "/etc/systemd/system/$RECOVERY_SERVICE" >/dev/null
sudo install -m 0644 \
  "$INSTALL_DIR/raspberry-pi/solaire-network-recovery.timer.example" \
  "/etc/systemd/system/$RECOVERY_TIMER"

# Verrouille les profils sur leurs interfaces dédiées. Le profil cabanon est
# aussi fixé sur le BSSID du routeur ESP : une Livebox ou un SSID similaire ne
# pourra jamais être choisi à sa place. Les mots de passe déjà enregistrés par
# NetworkManager ne sont ni affichés ni modifiés.
if nmcli -t -f NAME connection show | grep -Fxq "$ALFA_PROFILE"; then
  sudo nmcli connection modify "$ALFA_PROFILE" \
    connection.interface-name wlan2 connection.autoconnect yes \
    connection.autoconnect-priority 100 connection.autoconnect-retries 0 \
    802-11-wireless.ssid "$ALFA_SSID" 802-11-wireless.bssid "$ALFA_BSSID" \
    802-11-wireless.powersave 2 ipv4.never-default yes
else
  echo "Profil cabanon absent : $ALFA_PROFILE (aucune modification Wi-Fi effectuée)."
fi
if nmcli -t -f NAME connection show | grep -Fxq "$DTU_PROFILE"; then
  sudo nmcli connection modify "$DTU_PROFILE" \
    connection.interface-name wlan1 connection.autoconnect yes \
    connection.autoconnect-priority 100 connection.autoconnect-retries 0 \
    802-11-wireless.powersave 2 ipv4.never-default yes
else
  echo "Profil DTU absent : $DTU_PROFILE (aucune modification Wi-Fi effectuée)."
fi
# Le profil principal de la Livebox appartenait à wlan0 mais, sans cette
# contrainte, NetworkManager pouvait l'associer à wlan2 après une coupure.
if nmcli -t -f NAME connection show | grep -Fxq "$PRIMARY_WIFI_PROFILE"; then
  sudo nmcli connection modify "$PRIMARY_WIFI_PROFILE" \
    connection.interface-name wlan0 connection.autoconnect yes \
    connection.autoconnect-priority 200
else
  echo "Profil Wi-Fi principal absent : $PRIMARY_WIFI_PROFILE (aucune modification Wi-Fi effectuée)."
fi
sudo tee "$NETWORK_ENV" >/dev/null <<'EOF'
# Réseaux dédiés à l'installation solaire. Pas de mot de passe dans ce fichier.
ALFA_DEVICE=wlan2
ALFA_PROFILE=solaire-cabanon-alfa
ALFA_ROUTER_HOST=192.168.4.1
ALFA_PROXY_HOST=192.168.4.2
DTU_DEVICE=wlan1
DTU_PROFILE=dtu-direct-4p
DTU_HOST=10.10.100.254
DTU_USB_RESET_COOLDOWN=1800
EOF
sudo chmod 0644 "$NETWORK_ENV"
sudo systemctl daemon-reload
sudo systemctl enable --now "$SERVICE_NAME"
sudo systemctl enable --now "$RECOVERY_TIMER"

echo
echo "Installation terminée. Ouvrez : http://ADRESSE_DU_RASPBERRY:8765/"
echo "État du service : sudo systemctl status $SERVICE_NAME"
